<?php
return [
  'core' => [
    'class' => 'app\modules\core\Module',
  ],
  'dokter' => [
    'class' => 'app\modules\dokter\Module',
  ],
  'emr' => [
    'class' => 'app\modules\emr\Module',
  ],
  'master' => [
    'class' => 'app\modules\master\Module',
  ],
  'pendaftaran' => [
    'class' => 'app\modules\pendaftaran\Module',
  ],
  'pengaturan' => [
    'class' => 'app\modules\pengaturan\Module',
  ],
  'kepegawaian' => [
    'class' => 'app\modules\kepegawaian\Module',
  ],
  'komponen-tarif' => [
    'class' => 'app\modules\komponenTarif\Module',
  ],
  'manajemen-pelayanan' => [
    'class' => 'app\modules\manajemenPelayanan\Module',
  ],
  'rawat-jalan' => [
    'class' => 'app\modules\rawatJalan\Module',
  ],
  'rawat-inap' => [
    'class' => 'app\modules\rawatInap\Module',
  ],
  'farmasi' => [
    'class' => 'app\modules\farmasi\Module',
  ],
  'kasir' => [
    'class' => 'app\modules\kasir\Module',
  ],
  'inventori' => [
    'class' => 'app\modules\inventori\Module',
  ],
  'laporan' => [
    'class' => 'app\modules\laporan\Module',
  ],
  'keuangan' => [
    'class' => 'app\modules\keuangan\Module',
  ],
  'gridview' =>  [
    'class' => '\kartik\grid\Module'
  ],
];
