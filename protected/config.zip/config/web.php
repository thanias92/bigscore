<?php
$params = require __DIR__ . '/params.php';
$db = require __DIR__ . '/db.php';
$modules = require __DIR__ . "/modules.php";

$config = [
  'id' => 'Medig',
  'name' => 'Bigs +',
  // 'bootstrap' => ['log', 'queue'],
  "basePath" => dirname(__DIR__) . "/",
  "vendorPath" => dirname(__DIR__, 2) . "/vendor",
  "controllerNamespace" => "app\controllers",
  'aliases' => [
    '@bower' => '@vendor/bower-asset',
    '@npm'   => '@vendor/npm-asset',
  ],
  "timeZone" => "Asia/Jakarta",
  "language" => "id_ID",
  "defaultRoute" => "default",
  'on beforeAction' => function ($event) {
    return true;
  },
  'components' => [
    // 'queue' => [
    //   'class' => 'yii\queue\db\Queue',
    //   'db' => 'db',
    //   'tableName' => '{{%queue}}',
    //   'channel' => 'default',
    //   'mutex' => 'yii\mutex\PgsqlMutex',
    // ],
    'request' => [
      // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
      'cookieValidationKey' => 'ZBG5QqOz_ftRLeQXPSSsUMHjPQ7k9TUU',
      "parsers" => [
        "application/json" => "yii\web\JsonParser",
      ],
    ],
    'cache' => [
      'class' => 'yii\caching\FileCache',
    ],
    'user' => [
      "identityClass" => "app\models\User",
      "enableAutoLogin" => false,
      "authTimeout" => 3600 * 12,
      "loginUrl" => ["default/login"],
      // 'as loginOnce' => [
      //   'class' => 'app\components\LoginOnce',
      // ]
    ],
    "errorHandler" => [
      "errorAction" => "default/error",
    ],
    "authManager" => [
      "class" => 'yii\rbac\DbManager',
      "defaultRoles" => ["guest"],
    ],
    'session' => [
      'class' => 'yii\web\Session',
      // 'timeout' => 60 * 60 * 24 * 1, // 1 Day
      // 'writeCallback' => function ($session) {
      //   return [
      //     'user_id' => Yii::$app->user->id,
      //     'last_write' => time(),
      //   ];
      // },
    ],
    'mailer' => [
      'class' => \yii\symfonymailer\Mailer::class,
      'viewPath' => '@app/mail',
      'useFileTransport' => true,
    ],
    'log' => [
      'traceLevel' => YII_DEBUG ? 3 : 0,
      'targets' => [
        [
          'class' => 'yii\log\FileTarget',
          'levels' => ['error', 'warning'],
        ],
      ],
    ],
    'assetManager' => [
      'appendTimestamp' => true,
      'bundles' => [
        'yii\web\JqueryAsset' => [
          'sourcePath' => null,
          'basePath' => '@webroot',
          'baseUrl' => '@web',
          'js' => [
            'themes/js/core/libs.min.js',
          ],
          'css' => []
        ],
        'yii\bootstrap5\BootstrapAsset' => [
          'css' => [],
          'js' => [],
        ],
        'yii\bootstrap5\BootstrapPluginAsset' => [
          'css' => [],
          'js' => [],
        ],
        'kartik\select2\ThemeKrajeeAsset' => false,
        'kartik\select2\Select2Asset' => [
          'css' => [],
        ],
      ]
    ],
    'db' => $db,
    'urlManager' => [
      'enablePrettyUrl' => true,
      'showScriptName' => false,
      'rules' => [],
    ],
  ],
  'params' => $params,
  "modules" => $modules,
  "as access" => [
    "class" => "mdm\admin\components\AccessControl",
    "allowActions" => [
      "core/*",
      "debug/*",
      "gii/*",
      "datecontrol/*",
      "gridview/*",
      // "*"
    ],
  ],
];

if (YII_ENV_DEV) {
  // configuration adjustments for 'dev' environment
  $config['bootstrap'][] = 'debug';
  $config['modules']['debug'] = [
    'class' => 'yii\debug\Module',
    // uncomment the following to add your IP if you are not connecting from localhost.
    //'allowedIPs' => ['127.0.0.1', '::1'],
  ];

  $config['bootstrap'][] = 'gii';
  $config['modules']['gii'] = [
    'class' => 'yii\gii\Module',
    // uncomment the following to add your IP if you are not connecting from localhost.
    //'allowedIPs' => ['127.0.0.1', '::1'],
  ];
  $config['modules']['gii'] = [
    'class' => 'yii\gii\Module',
    'allowedIPs' => ['127.0.0.1', '::1', '192.168.0.*', '192.168.178.20'],
    'generators' => [
      'crud' => [
        'class' => 'app\GiiCustom\crud\Generator',
        'templates' => [
          'default' => '@app/GiiCustom/crud/default',
        ]
      ],
      'module' => [
        'class' => 'yii\gii\generators\module\Generator',
        'templates' => [
          'default' => '@app/GiiCustom/module/default',
        ]
      ],
      'model' => [
        'class' => 'yii\gii\generators\model\Generator',
        'templates' => [
          'default' => '@app/GiiCustom/model/default',
        ]
      ]
    ],
  ];
}

return $config;
