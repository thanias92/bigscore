<?php
return [
  'info' => require __DIR__ . '/local_params.php',
  'general' => require __DIR__ . '/_general_params.php',
  'bsVersion' => '5.x',
  'bsDependencyEnabled' => false,
];
