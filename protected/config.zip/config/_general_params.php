<?php
return [
    'agama' => [
        'Islam' => 'Islam',
        'Protestan' => 'Protestan',
        'Budha' => 'Budha',
    ],
    'panggilan' => [
        'Tn.' => 'Tn.',
        'Ny.' => 'Ny.',
        'By.' => 'By.',
    ],
    'jenis_kelamin' => [
        'Laki-laki' => 'Laki-laki',
        'Perempuan' => 'Perempuan'
    ],
    'status_perkawinan' => [
        'Menikah' => 'Menikah',
        'Belum menikah' => 'Belum menikah',
        'Duda' => 'Duda',
        'Janda' => 'Janda',
    ],
    'golongan_darah' => [
        'A' => 'A',
        'B' => 'B',
        'O' => 'O',
        'AB' => 'AB',
    ],
    'pembelian_dari' => [
        'Walk In' => 'Walk In',
    ],
    'jenis_registrasi' => [
        'otc' => 'OTC',
        'rawat_jalan' => 'Rawat Jalan',
        'rawat_inap' => 'Rawat Inap',
        'igd' => 'IGD',
        'penunjang' => 'Penunjang',
    ]
];
